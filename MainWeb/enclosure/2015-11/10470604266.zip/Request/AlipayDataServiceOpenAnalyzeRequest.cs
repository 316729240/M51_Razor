using System;
using System.Collections.Generic;
using Aop.Api.Response;

namespace Aop.Api.Request
{
    /// <summary>
    /// AOP API: alipay.data.service.open.analyze
    /// </summary>
    public class AlipayDataServiceOpenAnalyzeRequest : IAopRequest<AlipayDataServiceOpenAnalyzeResponse>
    {
        /// <summary>
        /// 传入biz_no等信息
        /// </summary>
        public string ExtraInfos { get; set; }

        /// <summary>
        /// 服务入参，多个入参json格式
        /// </summary>
        public string Params { get; set; }

        /// <summary>
        /// 调用者信息，必须传入app_id和app_name;可选pid
        /// </summary>
        public string PartnerInfo { get; set; }

        /// <summary>
        /// 服务名
        /// </summary>
        public string ServiceName { get; set; }

        #region IAopRequest Members
        private string apiVersion = "1.0";
		private string terminalType;
		private string terminalInfo;
        private string prodCode;
		private string notifyUrl;

		public void SetNotifyUrl(string notifyUrl){
            this.notifyUrl = notifyUrl;
        }

        public string GetNotifyUrl(){
            return this.notifyUrl;
        }

        public void SetTerminalType(String terminalType){
			this.terminalType=terminalType;
		}

    	public string GetTerminalType(){
    		return this.terminalType;
    	}

    	public void SetTerminalInfo(String terminalInfo){
    		this.terminalInfo=terminalInfo;
    	}

    	public string GetTerminalInfo(){
    		return this.terminalInfo;
    	}

        public void SetProdCode(String prodCode){
            this.prodCode=prodCode;
        }

        public string GetProdCode(){
            return this.prodCode;
        }

        public string GetApiName()
        {
            return "alipay.data.service.open.analyze";
        }

        public void SetApiVersion(string apiVersion){
            this.apiVersion=apiVersion;
        }

        public string GetApiVersion(){
            return this.apiVersion;
        }

        public IDictionary<string, string> GetParameters()
        {
            AopDictionary parameters = new AopDictionary();
            parameters.Add("extra_infos", this.ExtraInfos);
            parameters.Add("params", this.Params);
            parameters.Add("partner_info", this.PartnerInfo);
            parameters.Add("service_name", this.ServiceName);
            return parameters;
        }

        #endregion
    }
}
