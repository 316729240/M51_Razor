using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMarketingCdpAdvertiseOperateResponse.
    /// </summary>
    public class AlipayMarketingCdpAdvertiseOperateResponse : AopResponse
    {
    }
}
