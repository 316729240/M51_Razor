using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMobilePublicTemplateMessageDeleteResponse.
    /// </summary>
    public class AlipayMobilePublicTemplateMessageDeleteResponse : AopResponse
    {
    }
}
