using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMobileSecuinfosInformationReceiveResponse.
    /// </summary>
    public class AlipayMobileSecuinfosInformationReceiveResponse : AopResponse
    {
    }
}
