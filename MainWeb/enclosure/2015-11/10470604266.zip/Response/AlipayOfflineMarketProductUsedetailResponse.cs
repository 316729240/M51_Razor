using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMarketProductUsedetailResponse.
    /// </summary>
    public class AlipayOfflineMarketProductUsedetailResponse : AopResponse
    {
    }
}
