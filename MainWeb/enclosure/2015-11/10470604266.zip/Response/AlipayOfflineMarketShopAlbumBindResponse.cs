using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMarketShopAlbumBindResponse.
    /// </summary>
    public class AlipayOfflineMarketShopAlbumBindResponse : AopResponse
    {
    }
}
