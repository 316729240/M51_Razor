using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMarketShopAlbumModifyResponse.
    /// </summary>
    public class AlipayOfflineMarketShopAlbumModifyResponse : AopResponse
    {
    }
}
