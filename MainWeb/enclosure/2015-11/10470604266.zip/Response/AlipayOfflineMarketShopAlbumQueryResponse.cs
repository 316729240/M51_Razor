using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMarketShopAlbumQueryResponse.
    /// </summary>
    public class AlipayOfflineMarketShopAlbumQueryResponse : AopResponse
    {
    }
}
