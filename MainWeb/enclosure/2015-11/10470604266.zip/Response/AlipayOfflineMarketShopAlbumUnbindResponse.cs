using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMarketShopAlbumUnbindResponse.
    /// </summary>
    public class AlipayOfflineMarketShopAlbumUnbindResponse : AopResponse
    {
    }
}
