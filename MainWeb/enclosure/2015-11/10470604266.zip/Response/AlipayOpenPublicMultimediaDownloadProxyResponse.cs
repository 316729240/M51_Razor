using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicMultimediaDownloadProxyResponse.
    /// </summary>
    public class AlipayOpenPublicMultimediaDownloadProxyResponse : AopResponse
    {
    }
}
